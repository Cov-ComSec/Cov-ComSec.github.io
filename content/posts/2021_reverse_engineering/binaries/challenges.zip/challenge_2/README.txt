BE CAREFUL PLAYING WITH THIS IT CAN ENCRYPT YOUR FILES.

As long as you run it on an isolated folder or a VM you should be fine. The purpose of the challenge is to introduce people to the concept of reverse engineering a baby randomware. The main target of the challenge is to write a decryptor using the language of your choice. 

P.S. This is for EDUCATIONAL and DEMONSTRATION purposes only, the creator carries no responsibilities if your files get encrypted.